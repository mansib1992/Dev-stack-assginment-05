export const defaultTechnologies = [
  {
    id: "react",
    name: "React",
    category: "Frontend",
    description: "A declarative, component-based JavaScript library for building modern user interfaces.",
    icon: "https://icon.icepanel.io/Technology/svg/React.svg",
    rating: 4.9,
    difficulty: "Beginner-Friendly",
    badge: "Popular"
  },
  {
    id: "vue",
    name: "Vue.js",
    category: "Frontend",
    description: "An approachable, performant, and versatile framework for building web user interfaces.",
    icon: "https://icon.icepanel.io/Technology/svg/Vue.js.svg",
    rating: 4.8,
    difficulty: "Beginner-Friendly",
    badge: "Versatile"
  },
  {
    id: "svelte",
    name: "Svelte",
    category: "Frontend",
    description: "Cybernetically enhanced web apps with compile-time reactivity and zero virtual DOM overhead.",
    icon: "https://icon.icepanel.io/Technology/svg/Svelte.svg",
    rating: 4.8,
    difficulty: "Intermediate",
    badge: "Fast"
  },
  {
    id: "nextjs",
    name: "Next.js",
    category: "Frontend",
    description: "The React framework for full-stack web applications with hybrid static & server rendering.",
    icon: "https://icon.icepanel.io/Technology/svg/Next.js.svg",
    rating: 4.9,
    difficulty: "Intermediate",
    badge: "Popular"
  },
  {
    id: "nodejs",
    name: "Node.js",
    category: "Backend",
    description: "An asynchronous event-driven JavaScript runtime built on Chrome's V8 engine.",
    icon: "https://icon.icepanel.io/Technology/svg/Node.js.svg",
    rating: 4.8,
    difficulty: "Intermediate",
    badge: "Standard"
  },
  {
    id: "postgresql",
    name: "PostgreSQL",
    category: "Database",
    description: "A powerful, open-source object-relational database system with proven reliability.",
    icon: "https://icon.icepanel.io/Technology/svg/PostgresSQL.svg",
    rating: 4.9,
    difficulty: "Intermediate",
    badge: "Top SQL"
  },
  {
    id: "redis",
    name: "Redis",
    category: "Database",
    description: "In-memory data structure store used as a high-speed database, cache, and message broker.",
    icon: "https://icon.icepanel.io/Technology/svg/Redis.svg",
    rating: 4.8,
    difficulty: "Intermediate",
    badge: "Cache"
  },
  {
    id: "javascript",
    name: "JavaScript",
    category: "Language",
    description: "The versatile, ubiquitous scripting language powering dynamic behavior across the web.",
    icon: "https://icon.icepanel.io/Technology/svg/JavaScript.svg",
    rating: 4.9,
    difficulty: "Beginner-Friendly",
    badge: "Ubiquitous"
  },
  {
    id: "typescript",
    name: "TypeScript",
    category: "Language",
    description: "A strongly typed programming language that builds on JavaScript for robust tooling.",
    icon: "https://icon.icepanel.io/Technology/svg/TypeScript.svg",
    rating: 4.9,
    difficulty: "Intermediate",
    badge: "Essential"
  },
  {
    id: "java",
    name: "Java",
    category: "Language",
    description: "A secure, object-oriented programming language designed for portability and scale.",
    icon: "https://icon.icepanel.io/Technology/svg/Java.svg",
    rating: 4.6,
    difficulty: "Intermediate",
    badge: "Robust"
  },
  {
    id: "tailwind",
    name: "Tailwind CSS",
    category: "Styling",
    description: "A utility-first CSS framework packed with classes that can be composed to build custom UI.",
    icon: "https://icon.icepanel.io/Technology/svg/Tailwind-CSS.svg",
    rating: 4.9,
    difficulty: "Beginner-Friendly",
    badge: "Modern"
  },
  {
    id: "docker",
    "name": "Docker",
    category: "DevOps",
    description: "A platform designed to build, share, and run containerized applications reliably.",
    icon: "https://icon.icepanel.io/Technology/svg/Docker.svg",
    rating: 4.9,
    difficulty: "Intermediate",
    badge: "Containers"
  }
];
